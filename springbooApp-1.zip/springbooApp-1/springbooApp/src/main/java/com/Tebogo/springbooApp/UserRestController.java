import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import nl.blogspot.javasolutionsguide.springRestAndDataJpaWithSpringBoot.entity.Users;
import nl.blogspot.javasolutionsguide.springRestAndDataJpaWithSpringBoot.service.UserService;

/**
 * @RestController
 *
 */
@RestController
public class UserRestController {

    @Autowired
    private UserService UserService;

    public void UserService(UserService userService) {
        this.UserService = userService;
    }

    @GetMapping("/api/users/(userId)")
    public List<Users> getUsers() {
        List<Users> users = userService.retrieveUsers();
        return users;
    }

    @GetMapping("/api/users/{userId}")
    public Users getUsername(@PathVariable(name="userId")Long userId)
    {
        return UserService.getUsername(userId);
    }

    @PostMapping("/api/users")
    public void saveUser(Username username,Password Password )
    {
        UserService.saveUser(username, password);
        System.out.println("User Saved Successfully");
    }

    @DeleteMapping("/api/users/{userId}")
    public void deleteUser(@PathVariable(name="userId")Long userId){
        UserService.deleteUser(userId);
        System.out.println("User Deleted Successfully");
    }

    @PutMapping("/api/users/{userId}")
    public void updateUser(@RequestBody Users user,
                           @PathVariable(name="userId")Long userId){
        User usr = UserService.getUsername(userId);
        if(usr != null){
            UserService.updateUser(user);
        }

    }

}