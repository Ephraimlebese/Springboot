import java.util.List;

import nl.blogspot.javasolutionsguide.springRestAndDataJpaWithSpringBoot.entity.Employee;

/**
 * @author JavaSolutionsGuide
 *
 */
public interface UserService {
    public List<Users> retrieveUsers();

    public Users getUsers(Long userId);

    public void saveUsers(User userId);

    public void deleteUser(Long userId);

    public void updateUser(User user);
}