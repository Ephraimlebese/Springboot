package com.Tebogo.springbooApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
@EnableSwagger2
@ComponetSCAN(basePackages = "com.Tebogo.springbooApp")
public class SpringbooAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbooAppApplication.class, args);
	}
}
