package com.Tebogo.springbooApp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



/**
 * Getter and setter Methods
 * for users table
 */

@Entity

public class Users {
	@Id
	public ObjectId _id;

	public String username;
	public String password;
	Public int phone_number;

	public Users() {}

	public Users(ObjectId _id, String username, String password, int phone_number) {
		this._id = _id;
		this.username = username;
		this.password = password;
		this.phone_number = phone_number;
	}

	public void set_id(ObjectId _id) { this._id = _id; }

	public String get_id() { return this._id.toHexString(); }

	public void setPassword(String password) { this.password = password; }

	public String getPassword() { return password; }

	public void setUsername(String username) { this.username = username; }

	public String getUsername() { return username; }

	public void setPhoneNumber(Int phone_number) { this.phone_number = phone_number; }

	public String getPhonenumber() { return phone_number; }
}